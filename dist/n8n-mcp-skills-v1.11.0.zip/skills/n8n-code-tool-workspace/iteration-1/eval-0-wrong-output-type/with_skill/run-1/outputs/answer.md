# Why "Wrong output type returned" happens

Nothing is wrong with your JavaScript — the problem is that the **Custom Code Tool is not a Code node**, even though it looks identical in the editor.

- The regular **Code node** (`n8n-nodes-base.code`) is invoked by the previous node in the workflow and must return an **array of items**: `[{json: {...}}]`. That's why your pattern works fine there.
- The **Custom Code Tool** (`@n8n/n8n-nodes-langchain.toolCode`) is a LangChain tool invoked by the AI Agent. Its contract is **string in, string out**. The return value is fed back to the LLM as the tool's observation, so it must be a string (numbers are auto-converted).

When you return `[{json: {result: total}}]` from a Code Tool, n8n rejects the item-array format with exactly the error you're seeing: **"Wrong output type returned"**.

## The fix

Return a string instead. For structured data, `JSON.stringify()` it:

```javascript
// ❌ Code node format — fails in a Code Tool
return [{ json: { result: total } }];

// ✅ Code Tool format — return a JSON string
return JSON.stringify({ result: total });
```

If the result is a simple scalar, this also works:

```javascript
return total;          // numbers are auto-converted to a string
return String(total);  // or be explicit
```

JSON-stringifying is the recommended pattern for anything beyond a trivial scalar — the LLM parses JSON reliably and can pick out the fields it needs.

Note: a plain object (`return { result: total };`) also fails, just with a different error ("The response property should be a string, but it is an object"). Always end with a string.

## Other Code-node habits that don't carry over

While you're in there, double-check you're not relying on other Code-node features — the Code Tool sandbox is much narrower:

| Feature | Code node | Code Tool |
|---|---|---|
| Input | `$input.all()`, `$json` | the `query` variable (string or object from the LLM) |
| Return | `[{json: {...}}]` | a string |
| `$helpers.httpRequest()` | ✅ | ❌ not available |
| `$fromAI()` | ❌ | ❌ (throws "No execution data available") |
| `$node["..."]`, `$getWorkflowStaticData` | ✅ | ❌ |

So if `total` was supposed to come from `$input` or `$json`, that won't work either — read the AI's input from `query` instead. For example:

```javascript
// query is a string by default; tell the LLM (in the tool description)
// to send JSON, then parse it
let params;
try {
  params = typeof query === 'string' ? JSON.parse(query) : query;
} catch (e) {
  throw new Error('Expected a JSON object: ' + e.message);
}

const total = Number(params.price) * Number(params.quantity);

return JSON.stringify({ result: total });
```

If you need multiple typed parameters, consider enabling **Specify Input Schema** (`specifyInputSchema: true`) so the LLM sends a validated object and you can use `query.price`, `query.quantity` directly.

**Rule of thumb:** the Code Tool is "string in, string out." If you find yourself needing `$helpers`, other nodes' data, or `$fromAI()`, use a Call Sub-workflow Tool (`toolWorkflow`) or HTTP Request Tool instead.
