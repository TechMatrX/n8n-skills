# Why your Code Tool fails with "Wrong output type returned"

The **Code Tool** (the "Custom Code Tool" you attach to an AI Agent) is **not** the same as a regular **Code node**, even though they both let you write JavaScript. They have completely different input/output contracts:

| | Code node | Code Tool (AI Agent tool) |
|---|---|---|
| Input | Items from previous node (`$input.all()`, `$json`) | A single `query` variable (what the LLM sends to the tool) |
| Output | An **array of items**: `[{json: {...}}]` | A **single value the LLM can read — a string** (or something n8n can stringify) |

Your code:

```javascript
return [{json: {result: total}}];
```

works in a Code node because Code nodes must return an array of items. But a tool's output is fed back to the language model as text, so the Code Tool expects you to return a **plain string** (a number or simple primitive is also fine — it gets converted). Returning an array of item objects is the "wrong output type" the error is complaining about.

## The fix

Return the value directly, as a string:

```javascript
// ... your calculation of `total` ...

return String(total);
```

If you want to return structured data so the agent gets more context, stringify it:

```javascript
return JSON.stringify({ result: total });
```

Both are valid — the key is: **no `[{json: ...}]` wrapper, just the value itself**.

## Other Code Tool gotchas to keep in mind

- **Input comes in via `query`**, not `$json` / `$input`. If the tool needs parameters from the model, parse them from `query` (it's a string unless you enable "Specify Input Schema", in which case `query` is an object matching your schema).
- Don't `return` n8n item arrays anywhere in the tool — every return path must produce a string/primitive.
- If your calculation can fail, wrap it and return an error message as a string (e.g. `return "Error: " + err.message;`) — that way the agent can read the failure and react, instead of the tool crashing.

So in short: same language, different contract. Code node → array of items; Code Tool → a string for the LLM.
