# Defining multiple typed inputs for a Code Tool

The right way is to **stop parsing strings entirely** and turn the Code Tool into a structured tool by setting **`specifyInputSchema: true`**. That converts it from a LangChain `DynamicTool` (one free-form string in `query`) into a `DynamicStructuredTool`: the LLM sees a typed argument schema with named fields, the runtime validates the call *before* your code runs, and `query` arrives as a **validated object** instead of a string you have to split apart.

This fixes both of your problems at once:

- No more comma-splitting / `JSON.parse` failures — the agent can't send a malformed call; invalid calls are rejected before your code executes.
- Numeric fields stay numeric — no more `Number(...)` coercion on every field.

## Option A (recommended): `fromJson` — paste an example, n8n infers the schema

Requires Code Tool `typeVersion` ≥ 1.3. You give n8n one representative example JSON and it generates the schema:

```json
{
  "parameters": {
    "name": "calculate_leasing",
    "description": "Deterministically computes the monthly leasing payment given the vehicle price, term in months, and residual value percent. Use whenever the user asks for leasing cost, monthly payment, or a leasing breakdown.",
    "language": "javaScript",
    "specifyInputSchema": true,
    "schemaType": "fromJson",
    "jsonSchemaExample": "{\n  \"price\": 439900,\n  \"months\": 36,\n  \"residual_percent\": 50\n}",
    "jsCode": "// query is now a validated OBJECT, not a string\nconst { price, months, residual_percent } = query;\n\nconst residual = price * (residual_percent / 100);\nconst depreciation = price - residual;\nconst monthly_payment = depreciation / months;\n\nreturn JSON.stringify({\n  monthly_payment: Math.round(monthly_payment),\n  residual_value: Math.round(residual),\n  total_paid: Math.round(monthly_payment * months)\n});"
  },
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "typeVersion": 1.3,
  "name": "calculate_leasing"
}
```

(Adjust the math to your actual leasing formula — if you charge interest on the financed amount, add a `rate` field the same way.)

In the n8n editor this is: open the Code Tool → enable **"Specify Input Schema"** → choose **"Generate From JSON Example"** → paste the example object.

## Option B: `manual` — write the JSON Schema yourself

Worth it when you want per-field descriptions (the LLM reads them), numeric constraints, or explicit required/optional fields. Works from `typeVersion` 1.2:

```json
{
  "parameters": {
    "name": "calculate_leasing",
    "description": "Computes the monthly leasing payment.",
    "language": "javaScript",
    "specifyInputSchema": true,
    "schemaType": "manual",
    "inputSchema": "{\n  \"type\": \"object\",\n  \"required\": [\"price\", \"months\", \"residual_percent\"],\n  \"properties\": {\n    \"price\": { \"type\": \"number\", \"description\": \"Vehicle price in your currency\" },\n    \"months\": { \"type\": \"integer\", \"minimum\": 1, \"description\": \"Leasing term in months\" },\n    \"residual_percent\": { \"type\": \"number\", \"minimum\": 0, \"maximum\": 99, \"description\": \"Residual value as a percent of price, e.g. 50\" }\n  }\n}",
    "jsCode": "const { price, months, residual_percent } = query;\nconst residual = price * (residual_percent / 100);\nconst monthly_payment = (price - residual) / months;\nreturn JSON.stringify({ monthly_payment: Math.round(monthly_payment), residual_value: Math.round(residual) });"
  },
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "typeVersion": 1.3,
  "name": "calculate_leasing"
}
```

## What changes in your code

| Mode | Type of `query` | Access pattern |
|---|---|---|
| Unstructured (your current setup) | `string` | split/parse it yourself — fragile |
| Structured (`specifyInputSchema: true`) | validated `object` | `const { price, months, residual_percent } = query;` |

So delete your comma-splitting code entirely. With the schema enabled, this is all you need:

```javascript
const { price, months, residual_percent } = query;
```

(In Python the input variable is `_query` — a string without schema, a dict with schema.)

## Things that bite people

1. **Still return a string.** The structured schema only changes the *input*. The return value must be a string — use `return JSON.stringify({...})`. Returning a raw object throws `"The response property should be a string, but it is an object"`.
2. **`jsonSchemaExample` / `inputSchema` are strings containing JSON**, not JSON objects. If you edit the workflow JSON directly, watch the escaping. If the node won't save or the agent doesn't see your fields, validate the JSON separately first.
3. **Version check**: `fromJson` needs node `typeVersion` ≥ 1.3; `manual` works from 1.2. Set `typeVersion: 1.3` on the node.
4. **Reload the agent after flipping the schema on.** If the agent was already running against the old unstructured tool, it may keep sending the old comma-string format until the agent node is re-opened / the run is restarted.
5. **Keep the tool name snake_case and descriptive** (`calculate_leasing`, not `Code Tool`) and keep the description focused on *when* to call it — with a schema, you no longer need to document the input format in the description; the schema speaks for itself.
6. **Don't reach for `$fromAI()`** to get typed inputs — it's not available inside the Code Tool sandbox (it throws `"No execution data available"`). `specifyInputSchema` is the correct mechanism for `toolCode`. If you ever need many complex typed parameters plus `$helpers`/credentials, the alternative is a `toolWorkflow` (Call Sub-workflow Tool) instead.

## Optional: defensive validation inside the code

The schema already enforces types, but a couple of domain checks make errors readable for the agent:

```javascript
const { price, months, residual_percent } = query;
if (price <= 0) throw new Error('price must be > 0');
if (months < 1) throw new Error('months must be >= 1');
if (residual_percent < 0 || residual_percent >= 100) throw new Error('residual_percent must be in [0, 100)');
```

Thrown errors are surfaced back to the agent, which will usually correct the call and retry.
