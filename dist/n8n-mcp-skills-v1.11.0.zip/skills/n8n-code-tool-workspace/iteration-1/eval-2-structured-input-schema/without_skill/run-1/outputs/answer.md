# Defining multiple typed inputs for a Code Tool (no more comma-separated strings)

The problem you're hitting is the Code Tool's **default input mode**: when you don't define an input schema, the tool exposes a single string parameter (`query`) to the agent. The LLM then has no choice but to cram everything into one string ("120000, 36, 20"), and you're left parsing it yourself — which breaks as soon as the model changes its formatting.

The fix: enable **"Specify Input Schema"** on the Code Tool and define a proper JSON Schema with three typed fields. The agent will then call the tool with a structured object, and `query` inside your code becomes a parsed object — no string parsing at all.

## Step-by-step in the UI

1. Open your **Code Tool** node (the one attached to the AI Agent's *Tool* input).
2. Toggle **Specify Input Schema** → ON.
3. Set **Schema Type** to **Define using JSON Schema** (manual). You could also use *Generate From JSON Example*, but the manual schema lets you set exact types, descriptions, and required fields — which is what guides the LLM to fill the arguments correctly.
4. Paste this as the **Input Schema**:

```json
{
  "type": "object",
  "properties": {
    "price": {
      "type": "number",
      "description": "Net purchase price of the vehicle/asset, e.g. 120000"
    },
    "months": {
      "type": "integer",
      "description": "Lease term in months, e.g. 36"
    },
    "residual_percent": {
      "type": "number",
      "description": "Residual (buyout) value as a percentage of price, e.g. 20 for 20%"
    }
  },
  "required": ["price", "months", "residual_percent"],
  "additionalProperties": false
}
```

5. Give the tool a clear **Name** (e.g. `leasing_calculator`) and **Description** (e.g. *"Calculates the monthly leasing payment. Call with price (number), months (integer), and residual_percent (number, 0–100)."*). The model reads both the description and the per-field schema descriptions when deciding how to call the tool — good descriptions matter as much as the schema itself.

## The code

With a schema defined, `query` is an **object**, not a string:

```javascript
// query is already a parsed object matching the schema
const { price, months, residual_percent } = query;

// Defensive coercion — some models occasionally send numbers as strings
const p = Number(price);
const m = Number(months);
const r = Number(residual_percent);

if (!Number.isFinite(p) || !Number.isFinite(m) || !Number.isFinite(r) || m <= 0) {
  return JSON.stringify({ error: "Invalid input: price, months and residual_percent must be numbers, months > 0" });
}

const residualValue = p * (r / 100);
const monthlyPayment = (p - residualValue) / m;

// Tools must return a string — stringify structured results
return JSON.stringify({
  price: p,
  months: m,
  residual_percent: r,
  residualValue: Math.round(residualValue * 100) / 100,
  monthlyPayment: Math.round(monthlyPayment * 100) / 100
});
```

Note the final `return JSON.stringify(...)` — a Code Tool should return a **string** back to the agent. Returning a JSON string keeps the result unambiguous for the model.

## Equivalent node JSON

If you're editing workflow JSON directly, the relevant node looks like this:

```json
{
  "name": "leasing_calculator",
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "typeVersion": 1.1,
  "parameters": {
    "name": "leasing_calculator",
    "description": "Calculates the monthly leasing payment. Call with price (number), months (integer), and residual_percent (number, 0-100).",
    "language": "javaScript",
    "jsCode": "const { price, months, residual_percent } = query;\nconst p = Number(price);\nconst m = Number(months);\nconst r = Number(residual_percent);\nif (!Number.isFinite(p) || !Number.isFinite(m) || !Number.isFinite(r) || m <= 0) {\n  return JSON.stringify({ error: 'Invalid input' });\n}\nconst residualValue = p * (r / 100);\nconst monthlyPayment = (p - residualValue) / m;\nreturn JSON.stringify({ residualValue: Math.round(residualValue * 100) / 100, monthlyPayment: Math.round(monthlyPayment * 100) / 100 });",
    "specifyInputSchema": true,
    "schemaType": "manual",
    "inputSchema": "{\n  \"type\": \"object\",\n  \"properties\": {\n    \"price\": { \"type\": \"number\", \"description\": \"Net purchase price, e.g. 120000\" },\n    \"months\": { \"type\": \"integer\", \"description\": \"Lease term in months, e.g. 36\" },\n    \"residual_percent\": { \"type\": \"number\", \"description\": \"Residual value as percent of price, e.g. 20\" }\n  },\n  \"required\": [\"price\", \"months\", \"residual_percent\"],\n  \"additionalProperties\": false\n}"
  }
}
```

It connects to the AI Agent via the `ai_tool` connection, same as before — only the parameters change.

## Why this works better than parsing a string

- **The schema is sent to the LLM as the tool's function signature.** Modern chat models use native function/tool-calling, so they emit `{"price": 120000, "months": 36, "residual_percent": 20}` directly — no free-text to parse.
- **Types are enforced at the model level.** `"type": "integer"` on `months` and `"required"` on all three fields strongly reduce missing/garbled arguments.
- **Field descriptions act as micro-prompts**, e.g. clarifying that `residual_percent` is `20`, not `0.2` — a classic ambiguity worth spelling out.

## A couple of extra tips

- If you ever prefer *Generate From JSON Example* mode, an example like `{"price": 120000, "months": 36, "residual_percent": 20}` works too — but it infers types from the example and can't express `required` or `integer` vs `number`, so manual schema is the better choice here.
- Keep the `Number(...)` coercion in the code anyway. Most models respect the schema, but defensive coercion makes the tool robust to the occasional `"36"` instead of `36`.
- If validation fails, return a JSON error string (as in the code above) rather than throwing — the agent can read the error and retry with corrected arguments.
