# Skill Benchmark: n8n-code-tool

**Model**: <model-name>
**Date**: 2026-06-12T13:27:05Z
**Evals**: 0, 1, 2 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 93% ± 12% | +0.07 |
| Time | 38.5s ± 8.9s | 38.8s ± 14.2s | -0.3s |
| Tokens | 33251 ± 2402 | 25150 ± 1387 | +8100 |