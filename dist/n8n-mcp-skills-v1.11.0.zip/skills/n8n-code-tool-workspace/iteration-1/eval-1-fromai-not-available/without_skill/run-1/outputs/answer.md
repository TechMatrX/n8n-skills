# Why `$fromAI()` fails in a Code Tool — and how to get the AI's input

## The problem

`$fromAI()` is **not available inside the Code Tool's code**. It only works in **expression fields of regular nodes used as tools** (e.g., HTTP Request Tool, Gmail Tool, Google Sheets Tool), where n8n substitutes the value into the parameter before the node runs:

```
// Works in an HTTP Request Tool's URL field, NOT in Code Tool code:
https://api.weather.com/v1/lookup?city={{ $fromAI('city', 'The city to look up') }}
```

Inside a Code Tool, calling `$fromAI()` has no execution context to resolve against, which is why you get the confusing `"No execution data available"` error (the "Cannot assign to read only property 'name'" part is just n8n mangling the error object while re-throwing — the real message is the inner one).

## How the Code Tool actually receives input

The Code Tool gets the AI's input through a special variable called **`query`**. There are two modes:

### Option 1: No input schema (simplest)

If **Specify Input Schema** is off, the agent sends a single string and `query` **is that string**:

```javascript
// 'query' is the raw string the AI passed to the tool
const city = query;

// ... do your lookup ...
const result = `Weather for ${city}: sunny, 22°C`;

// Return a string (or something stringifiable) to the agent
return result;
```

Make sure your tool **description** tells the model what to send, e.g.: *"Looks up weather. Input: the city name as a plain string."*

### Option 2: With an input schema (recommended for structured input)

Enable **Specify Input Schema** in the Code Tool and define the fields. For example, with this JSON schema:

```json
{
  "type": "object",
  "properties": {
    "city": {
      "type": "string",
      "description": "The city to look up"
    }
  },
  "required": ["city"]
}
```

`query` becomes an **object**, and you access the field directly:

```javascript
// 'query' is now a parsed object matching your schema
const city = query.city;

if (!city) {
  return "Error: no city provided. Please supply a 'city' parameter.";
}

const result = `Weather for ${city}: sunny, 22°C`;
return result;
```

This is the closest equivalent to what you were trying to do with `$fromAI('city', 'The city to look up')` — the schema's `description` plays the same role as the second argument of `$fromAI()`: it tells the model what the parameter means.

## Quick summary

| Where | How the AI's input arrives |
|---|---|
| Regular node used as a tool (HTTP Request Tool, Slack Tool, etc.) | `{{ $fromAI('key', 'description', 'type') }}` in expression fields |
| **Code Tool** | The `query` variable (string without schema, object with schema) |
| Custom Workflow Tool (sub-workflow) | The sub-workflow's trigger input / `$json.query` |

## Corrected code (with schema)

```javascript
const city = query.city; // instead of $fromAI('city', ...)

// your lookup logic here
return `Looking up weather for: ${city}`;
```

Also remember: a Code Tool must **return a value** (string preferred) — that return value is what gets handed back to the agent as the tool's observation.
