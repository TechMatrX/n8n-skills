# Why this fails

`$fromAI()` is **not available inside the Custom Code Tool** (`@n8n/n8n-nodes-langchain.toolCode`). That helper only works in *other* tool-enabled nodes — HTTP Request Tool, the Call Sub-workflow Tool (`toolWorkflow`), SendGrid Tool, etc. — where you bind individual parameter fields to AI-provided values. Inside the Code Tool's sandbox it isn't exposed, and calling it produces exactly the cryptic error you're seeing:

```
Cannot assign to read only property 'name' of object 'Error: No execution data available'
```

## How the Code Tool actually receives the AI's input

The AI's input arrives in a fixed, predefined variable:

- **JavaScript:** `query`
- **Python:** `_query`

You don't declare it — it's already in scope. And the return value must be a **string** (use `JSON.stringify()` for structured output), not the Code-node-style `[{json: {...}}]` array.

## Option 1: Single input (simplest)

If "city" is the only thing the tool needs, just use `query` directly:

```javascript
// `query` is the string the AI sends, e.g. "Berlin"
const city = query.trim();

// ... your lookup logic ...
return `Weather info for ${city}: ...`;
```

Then make the **tool description** tell the LLM what to send, e.g.:

> "Looks up information for a city. Call with the city name as plain text, e.g. `Berlin`."

The description is the contract the LLM sees — it decides what to pass based on it.

## Option 2: Multiple/typed fields — use the input schema (recommended)

If you need more than one field (or want validation), enable **Specify Input Schema** (`specifyInputSchema: true`) on the Code Tool. The easiest setup is **Generate From JSON Example** (`schemaType: "fromJson"`) with an example like:

```json
{ "city": "Berlin", "country": "DE" }
```

Then `query` arrives as a **validated object** and you access fields directly:

```javascript
// query is now an object matching your schema
const city = query.city;
const country = query.country;

// ... your lookup logic ...
return JSON.stringify({ city, country, result: "..." });
```

This is the closest equivalent to what you were trying to do with `$fromAI('city', 'The city to look up')` — the schema (with field descriptions) is what tells the LLM which arguments to provide.

## Option 3: If you really want `$fromAI()` semantics

If your tool grows beyond pure computation (needs `$helpers.httpRequest`, credentials, other nodes, or per-field `$fromAI()` bindings), switch node types:

- **HTTP Request Tool** — if the tool is fundamentally one API call; supports `$fromAI()` directly in URL/query/body fields.
- **Call Sub-workflow Tool (`toolWorkflow`)** — multi-step logic in a sub-workflow with the full Code-node sandbox and clean `$fromAI()`-typed inputs.

Rule of thumb: if you find yourself reaching for `$fromAI()`, you probably want `toolWorkflow` or the HTTP Request Tool instead of `toolCode`.

## Corrected version of your code

```javascript
// ❌ Before — $fromAI is not available in the Code Tool sandbox
// const city = $fromAI('city', 'The city to look up');

// ✅ After — read the AI's input from `query`
// (works for plain-string mode; also handles a JSON-string just in case)
let city;
if (typeof query === 'string') {
  try {
    const parsed = JSON.parse(query);
    city = parsed.city ?? query;
  } catch {
    city = query; // plain city name like "Berlin"
  }
} else {
  city = query.city; // structured mode (specifyInputSchema: true)
}

if (!city || typeof city !== 'string') {
  throw new Error('Expected a city name, e.g. "Berlin"');
}

// ... your lookup logic here ...
const result = { city: city.trim(), info: 'lookup result here' };

// Must return a STRING (not an object, not [{json: ...}])
return JSON.stringify(result);
```

Also note: the Code Tool sandbox has **no** `$input`, `$json`, `$node`, `$helpers.httpRequest`, or `$getWorkflowStaticData` — it's meant for pure computation. If your "look up" needs an external API call, use the HTTP Request Tool instead.
